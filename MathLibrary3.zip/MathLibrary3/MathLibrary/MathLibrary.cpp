#include <iostream>
#include "../MathLibrary2/MathLibrary.h"
using namespace std;
int main()
{
	int x, y, z, H;
	cin >> x >> y >> z >> H;
	cout << P(x, y, z) << endl;
	cout << S(x, H);
}