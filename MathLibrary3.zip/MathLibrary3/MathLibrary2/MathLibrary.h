#pragma once
int P(int a, int b, int c);
int S(int a, int Ha);